// ���հ��ELDP����Ҫ��ȡʵ��������ʷֲ���

package ceka.ELDP;

import java.util.HashMap;
import java.util.Map.Entry;

import com.mathworks.toolbox.javabuilder.MWException;
import com.mathworks.toolbox.javabuilder.MWNumericArray;

import myqpmatlab.MyQP;
import ceka.core.Dataset;
import ceka.core.Example;
import ceka.core.Label;
import weka.core.Instance;
import weka.core.Utils;

public class ELDP {
	public int m_K = 20;
	public int m_iter = 5;
	public String NAME = "ELDP";
	public MyQP qp;
	public HashMap<String, double[]> MyPro;
	
	private int m_numAttributes = 0;
	private int m_numExamples = 0;
	private double[] m_MinArray;
	private double[] m_MaxArray;

	public void setK(int k) {
		m_K = k;
	}
	
	public void setT(int t) {
		m_iter = t;
	}

	public void setMyQP(MyQP t1) {
		qp = t1;
	}
	
	public void setMyPro(HashMap<String, double[]> temp) {
		MyPro = deepcopy(temp);
	}
	
	public double calHMOM(Instance ins1, Instance ins2) {
		double distance = 0;
		for(int m=0; m<m_numAttributes; m++) {
			if(m == ins1.classIndex()) continue;
			if(ins1.isMissing(m) || ins2.isMissing(m))
				distance += 1;
			else if(ins1.attribute(m).isNominal()) {
				distance += (ins1.value(m) == ins2.value(m)) ? 0 :1;
			}
			else {
				if((m_MaxArray[m] - m_MinArray[m]) == 0)
					distance += 0;
				else
					distance += Math.abs(ins1.value(m) - ins2.value(m)) / (m_MaxArray[m] - m_MinArray[m]);
			}
			
		}		
		return distance;
	}


	public HashMap<String, double[]> findk_nearestexamples_idanddistance(Dataset dataset,int index,int numofk) throws Exception{
		HashMap<String, double[]> map = new HashMap<>();
		Example example = dataset.getExampleByIndex(index);
		double[] distance = new double[m_numExamples];
		for(int i=0; i<m_numExamples; i++) {
			distance[i] = calHMOM(example, dataset.getExampleByIndex(i));
		}
		int[] indexDistanceSort = Utils.sort(distance);
		for(int i=1; i<numofk+1; i++) { //�ų��Լ�
			Example instance = dataset.getExampleByIndex(indexDistanceSort[i]);
			String exampleid = instance.getId();
			if(!map.containsKey(exampleid)) {
				map.put(exampleid, caluate(example, instance));	
			}
		}
		return map;
	}
	
	public void doInference(Dataset dataset) throws Exception {
		// ����������
		m_numExamples = dataset.getExampleSize();
		m_numAttributes = dataset.numAttributes();
		
		m_MinArray = new double[m_numAttributes];
		m_MaxArray = new double[m_numAttributes];
		for (int m = 0; m < m_numAttributes; m++)
			m_MinArray[m] = Double.NaN;
		for(int i=0; i<m_numExamples; i++) {
			double[] value = dataset.instance(i).toDoubleArray();
			for(int m=0; m<m_numAttributes; m++) {
				if(dataset.attribute(m).isNumeric() && (dataset.classIndex() != m)) {
					if (!Instance.isMissingValue(value[m])) {
						if (Double.isNaN(m_MinArray[m])) {
							m_MinArray[m] = m_MaxArray[m] = value[m];
						} else {
							if (value[m] < m_MinArray[m])
								m_MinArray[m] = value[m];
							if (value[m] > m_MaxArray[m])
								m_MaxArray[m] = value[m];
						}
					}					
				}
			}
		}
		
		
		//sQPtest = new QPtest();
		double[][] Aeq = new double[1][m_K];
		double[] beq = new double[1];
		double[] lb = new double[m_K];
		double[] ub = new double[m_K];
		double[] f = new double[m_K];
		double[][] A = new double[1][m_K];
		double[] b = new double[1];
		beq[0]  = 1;
		for(int i = 0;i < m_K;i++) {
			Aeq[0][i] = 1;
			lb[i] = 0;
			ub[i] = 1;
			f[i] = 0;
			A[0][i] = 0;
		}
		
		HashMap<String, HashMap<String, double[]>> knearestmap = new HashMap<>();
		HashMap<String, HashMap<String, Double>> knearestweightmap = new HashMap<>();
		
		for(int i = 0; i < m_numExamples; i++) {
			Example example = dataset.getExampleByIndex(i);
			HashMap<String, double[]> temp = findk_nearestexamples_idanddistance(dataset, i, m_K);//Ѱ�ҵ�i��������k�����ڼ���Ӧ�Ĳ�ֵ
			String eid = example.getId();
			knearestmap.put(eid, temp);
			double[][] H = hashmap2array(temp, example.numAttributes()-1);//��Ӧ�����еľ���G
			double[] weights = solveqp(H, f, A, b, Aeq, beq, lb, ub);
			HashMap<String, Double> weighttemp = new HashMap<>();
			int j = 0;
			for(String key: temp.keySet()) {
				weighttemp.put(key, weights[j]);
				j++;
			}
			knearestweightmap.put(eid, weighttemp);
		}
		//ͨ����������ÿ�������ĸ��ʷֲ�
		HashMap<String, double[]> initprobs = deepcopy(MyPro);
		HashMap<String, double[]> oldprobs = deepcopy(MyPro);
		HashMap<String, double[]> newprobs = new HashMap<>();
		for(int i = 0;i < m_iter;i++) {
			for(int j = 0;j < m_numExamples;j++) {
				double[] mu = new double[dataset.getCategorySize()];
				Example example = dataset.getExampleByIndex(j);
				String eid = example.getId();
				HashMap<String, Double> eMap = knearestweightmap.get(eid);
				double[] Pi = initprobs.get(eid);
				double alphaj = 0.5;
				mu = add(mu, Pi, 1, 1 - alphaj);
				for(String key : eMap.keySet()) {
					double[] mu_i = oldprobs.get(key);
					mu = add(mu, mu_i, 1, alphaj * eMap.get(key));
				}
				newprobs.put(eid, mu);
			}
			oldprobs = deepcopy(newprobs);
		}
		//����������ÿ�������ṩ�������
		for(int i=0; i<m_numExamples; i++) {
			Example example = dataset.getExampleByIndex(i);
			String eString = example.getId();
			double[] finalprobs = newprobs.get(eString);
			Integer value = Utils.maxIndex(finalprobs);
			Label integratedL = new Label(null, value.toString(), example.getId(), NAME);
			example.setIntegratedLabel(integratedL);
		}
		dataset.assignIntegeratedLabel2WekaInstanceClassValue();
	}

	public double[] solveqp(double[][]Htemp,double[]ftemp,double[][] Atemp,double[] btemp,
			double[][] Aeq,double[] beq,double[] lbtemp,double[] ubtemp) throws MWException {
		 Object[] result = qp.QP(1, Htemp,ftemp,Atemp,btemp,Aeq,beq,lbtemp,ubtemp);
		 MWNumericArray X = (MWNumericArray) result[0];
		 double[][] t = (double[][]) X.toDoubleArray();
		 double[] finalresult = new double[t.length];
		 for(int i = 0; i < finalresult.length;i++) {
			 finalresult[i] = t[i][0];
		 }
		 //sQPtest.dispose();//�ͷ�
		 return finalresult;
	}
	
	public double[][] hashmap2array(HashMap<String, double[]> temp,int numofparms) {
		int num = temp.size();
		//System.out.println("tempȨ�ظ���"+num);
		double[][] result = new double[num][num];
		double[][] temparray = new double[num][numofparms];//��hashmap��ת�ɶ�ά����
		int index = 0;
		for(String key : temp.keySet()) {
			temparray[index] = temp.get(key);
			index++;
		}
		int i = 0;
		int j = 0;//index
		while(i < num) {
			while(j < num) {
				result[i][j] = 2 * timearray(temparray[i], temparray[j]);
				j++;
			}
			j = 0;
			i++;
		}                 
		return result;
	}
	
	public double timearray(double[] a, double[] b) {
		double result = 0.0;
		for(int i = 0;i < a.length;i++) {
			result += a[i] * b[i];
		}
		return result;
	}
	
	public double[] caluate(Instance e1,Instance e2) {
		double[] t = new double[e1.numAttributes()-1];
		int index = 0;
		for(int i = 0;i < e1.numAttributes();i++) {
			if(i != e1.classIndex()) {
				t[index] = (e1.value(index) - e2.value(index));
				index++;
			}
		}
		return t;
	}
	
	public static double[] add(double[] a,double[] b,double per1,double per2) {
		double[] c = new double[a.length];
		for(int i = 0;i < a.length;i++) {
			c[i] = per1 * a[i] + per2 * b[i];
		}
		return c;
	}

	public static HashMap<String, double[]> deepcopy(HashMap<String, double[]> oldmap) {
		HashMap<String, double[]> newmap = new HashMap<>();
		for(Entry<String, double[]> entry : oldmap.entrySet()) {
			newmap.put(entry.getKey(), entry.getValue());
		}
		return newmap;
	}
	public static void main(String[] args) throws Exception {

	}
}
