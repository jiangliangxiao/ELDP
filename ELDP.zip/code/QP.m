function Y = QP(H,f,A,b,Aeq,beq,lb,ub)
[x,fval] = quadprog(H,f,A,b,Aeq,beq,lb,ub);
Y = x;