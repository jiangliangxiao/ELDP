/* ģ��ʵ��
 * */
package ceka.ELDP;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.HashMap;

import ceka.AALI.AALI;
import ceka.DEWSMV.OptimizedError;
import ceka.IWMV.IWMV;
import ceka.LAWMV.LAWMV;
import ceka.MNLDP.MNLDP;
import ceka.consensus.MajorityVote;
import ceka.converters.FileLoader;
import ceka.core.Category;
import ceka.core.Dataset;
import ceka.core.Example;
import ceka.core.Label;
import ceka.simulation.GaussianLabelingStrategy;
import ceka.simulation.MockWorker;
import ceka.utils.PerformanceStatistic;
import myqpmatlab.MyQP;
import weka.core.Instance;
import weka.core.Instances;
import weka.filters.Filter;
import weka.filters.unsupervised.attribute.ReplaceMissingValues;

public class Test_S {
	
	private static String dataSetArffDir = "./test/ceka/ELDP/simulation/";
	
	private static String[] dataSetArddFix = new File(dataSetArffDir).list();
	
	private static String runDir = "./test/ceka/ELDP/ELDP-results/";
	
	private static int times = 10;
	
	public static void main(String[] args) throws Exception {
		File testDir = new File(runDir);
		if (!testDir.exists())
			testDir.mkdirs();

		// write the result to a file
		FileOutputStream f_i = new FileOutputStream(new File(runDir + "ELDP_simu.txt"));
		PrintStream result_i = new PrintStream(f_i);

		result_i.format("%-10s	%-10s	%-10s	%-10s	%-10s	%-10s	%-10s	%-10s	%-10s", "Dataset","MV","IWMV","IRLI","IRLI_CHI","DEWSMV","MNLDP","LAWMV","ELDP");
		result_i.println();
		
		double Acc_mv_all_sum = 0.0;
		double Acc_iwmv_all_sum = 0.0;
		double Acc_irli_sum = 0.0;
		double Acc_irli_chi_sum = 0.0;
		double Acc_dewsmv_all_sum = 0.0;
		double Acc_mnldp_all_sum = 0.0;
		double Acc_lawmv_all_sum = 0.0;
		double Acc_eldp_all_sum = 0.0;
		
		for (int index = 0; index < dataSetArddFix.length; index++) {
			
			String datasetArffPath = dataSetArffDir + dataSetArddFix[index];
			Dataset dataset = FileLoader.loadFile(datasetArffPath);
			
			System.out.println(dataSetArddFix[index]);
			
			// Replace Missing Values
			ReplaceMissingValues m_Missing = new ReplaceMissingValues();
			m_Missing.setInputFormat(dataset);
			Instances instances = Filter.useFilter(dataset, m_Missing);
			
			dataset = instancesToDataset(instances,dataset);
			
			double Acc_mv = 0.0;
			double Acc_iwmv = 0.0;
			double Acc_irli = 0.0;
			double Acc_irli_chi = 0.0;
			double Acc_dewsmv = 0.0;
			double Acc_mnldp = 0.0;
			double Acc_lawmv = 0.0;
			double Acc_eldp = 0.0;
					
			for (int counts = 0; counts < times; counts++) {
				MockWorker[] mockWorkers_high = new MockWorker[1];
				MockWorker[] mockWorkers_low = new MockWorker[2];
				// low quality
				double mean = 1.0 / dataset.numClasses();
				double std = 0.1;
				GaussianLabelingStrategy strategy = new GaussianLabelingStrategy(mean, std);
				for (int j = 0; j < mockWorkers_low.length; j++) {
					mockWorkers_low[j] = new MockWorker(String.valueOf(j));
				}
				strategy.assignWorkerQuality(mockWorkers_low);
				for (int j = 0; j < mockWorkers_low.length; j++) {
					mockWorkers_low[j].labeling(dataset, strategy);
				}
				// high quality
				GaussianLabelingStrategy strategy_high = new GaussianLabelingStrategy(0.8, 0.1);
				for (int j = 0; j < mockWorkers_high.length; j++) {
					mockWorkers_high[j] = new MockWorker(String.valueOf(j+mockWorkers_low.length));
				}
				strategy_high.assignWorkerQuality(mockWorkers_high);
				for (int j = 0; j < mockWorkers_high.length; j++) {
					mockWorkers_high[j].labeling(dataset, strategy_high);
				}
				
				// MV
				Dataset datasetMV = datasetCopy(dataset);
				MajorityVote mv = new MajorityVote();
				mv.doInference(datasetMV);
				PerformanceStatistic reporter = new PerformanceStatistic();
				reporter.stat(datasetMV);
				Acc_mv += reporter.getAccuracy() * 100;
		
				//IWMV
				Dataset datasetIWMV = datasetCopy(dataset);
				IWMV iwmv = new IWMV();
				iwmv.doInference(datasetIWMV);
				reporter = new PerformanceStatistic();
				reporter.stat(datasetIWMV);
				Acc_iwmv += reporter.getAccuracy() * 100;
				
				//AALI
				Dataset datasetIRLI = datasetCopy(dataset);
				AALI irli = new AALI();
				datasetIRLI = irli.doInference(datasetIRLI);
				reporter = new PerformanceStatistic();
				reporter.stat(datasetIRLI);
				Acc_irli += reporter.getAccuracy() * 100;
				
				//CHI
				Dataset datasetIRLICHI = datasetCopy(dataset);
				CHI irli_chi = new CHI();
				irli_chi.doInference(datasetIRLICHI);
				HashMap<String, double[]> tempPro2 = irli_chi.getPro();
				reporter = new PerformanceStatistic();
				reporter.stat(datasetIRLICHI);
				Acc_irli_chi += reporter.getAccuracy() * 100;
				
				// DEWSMV algorithm
				Dataset datasetDEWSMV = datasetCopy(dataset);
				OptimizedError dewsmv = new OptimizedError();
				dewsmv.DE_search(datasetDEWSMV);
				reporter = new PerformanceStatistic();
				reporter.stat(datasetDEWSMV);
				Acc_dewsmv += reporter.getAccuracy() * 100;
				
				// MNLDP
				Dataset datasetMNLDP = datasetCopy(dataset);
				MNLDP mnldp = new MNLDP();
				MyQP t1 = new MyQP();
				mnldp.setMyQP(t1);
				mnldp.doInference(datasetMNLDP);
				t1.dispose();
				reporter = new PerformanceStatistic();
				reporter.stat(datasetMNLDP);
				Acc_mnldp += reporter.getAccuracy() * 100;
				
				//LAWMV
				Dataset datasetLAWMV = datasetCopy(dataset);
				LAWMV lawmv = new LAWMV();
				lawmv.doInference(datasetLAWMV, (int)(0.5*datasetLAWMV.numInstances() / datasetLAWMV.numClasses()));
				reporter = new PerformanceStatistic();
				reporter.stat(datasetLAWMV);
				Acc_lawmv += reporter.getAccuracy() * 100;
				
				//DEWError algorithm
				Dataset datasetELDP = datasetCopy(dataset);
				ELDP eldp = new ELDP();
				MyQP t2 = new MyQP();
				eldp.setMyPro(tempPro2);
				eldp.setMyQP(t2);
				eldp.doInference(datasetELDP);
				t2.dispose();
				reporter = new PerformanceStatistic();
				reporter.stat(datasetELDP);
				Acc_eldp += reporter.getAccuracy() * 100;
			}
			
			Acc_mv_all_sum += Acc_mv / times;
			Acc_iwmv_all_sum += Acc_iwmv / times;
			Acc_irli_sum += Acc_irli / times;
			Acc_irli_chi_sum += Acc_irli_chi / times;
			Acc_dewsmv_all_sum += Acc_dewsmv / times;
			Acc_mnldp_all_sum += Acc_mnldp / times;
			Acc_lawmv_all_sum += Acc_lawmv / times;
			Acc_eldp_all_sum += Acc_eldp / times;
			
			result_i.format("%-25s	%-10.2f	%-10.2f	%-10.2f	%-10.2f	%-10.2f	%-10.2f	%-10.2f	%-10.2f", dataSetArddFix[index],
					Acc_mv / times, Acc_iwmv / times,
					Acc_irli / times, Acc_irli_chi / times,
					Acc_dewsmv / times, Acc_mnldp / times,
					Acc_lawmv / times, Acc_eldp / times);
			result_i.println();
		}
		result_i.format("%-25s	%-10.2f	%-10.2f	%-10.2f	%-10.2f	%-10.2f	%-10.2f	%-10.2f	%-10.2f", "Average",
				Acc_mv_all_sum / dataSetArddFix.length,
				Acc_iwmv_all_sum / dataSetArddFix.length,
				Acc_irli_sum / dataSetArddFix.length,
				Acc_irli_chi_sum / dataSetArddFix.length,
				Acc_dewsmv_all_sum / dataSetArddFix.length,
				Acc_mnldp_all_sum / dataSetArddFix.length,
				Acc_lawmv_all_sum / dataSetArddFix.length,
				Acc_eldp_all_sum / dataSetArddFix.length);
		result_i.close();
	}
	
	public static double randdouble(double max, double min) {
		return (Math.random() * (max - min) + min);
	}
	
	public static Dataset datasetCopy(Dataset dataset) {
		Dataset newdataset = dataset.generateEmpty();
		int numCateSize = dataset.getCategorySize();
		for (int i = 0; i < numCateSize; i++) {
			Category cate = dataset.getCategory(i);
			newdataset.addCategory(cate.copy());
		}
		for (int j = 0; j < dataset.getExampleSize(); j++) {
			Example example = dataset.getExampleByIndex(j);
			newdataset.addExample(example);
		}
		for (int i = 0; i < dataset.getWorkerSize(); i++) {
			newdataset.addWorker(dataset.getWorkerByIndex(i));
		}
		return newdataset;
	}
	
	public static Dataset instancesToDataset(Instances instances,Dataset dataset1) {
		Dataset dataset = new Dataset(instances,instances.numInstances());
		for(int m = 0;m < dataset1.getCategorySize();m++) {
			Category cate = dataset1.getCategory(m);
			dataset.addCategory(cate.copy());
		}
		for(int i = 0;i < instances.numInstances();i++) {
			Instance instance = instances.instance(i);
			Integer truevalue = (int)instance.classValue();
			Example example = new Example(instance);
			Label truelabel = new Label(null, truevalue.toString(), example.getId(), "creat");
			example.setTrueLabel(truelabel);
			dataset.addExample(example);
		}
		return dataset;
	}
}
