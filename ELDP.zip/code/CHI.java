// for ELDP��׼�棨HMOM��
package ceka.ELDP;

import java.util.ArrayList;
import java.util.HashMap;

import ceka.core.Category;
import ceka.core.Dataset;
import ceka.core.Example;
import ceka.core.Label;
import ceka.core.MultiNoisyLabelSet;
import ceka.core.Worker;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.Utils;

// д���ĵİ汾
public class CHI {
	private int m_numClasses = 0;
	private int m_numAttributes = 0;
	private int m_numExamples = 0;
	public double[][] m_instanceProb; // ��ʵ�������������
	private Dataset[] subDatasets;
	private double[] m_MinArray;
	private double[] m_MaxArray;
	HashMap<String, double[]> m_probilities;
	HashMap<String, Dataset> subDataset;
	Instances m_Centroids;
	
	// �������ݼ�
	public static Dataset copyDataset(Dataset dataset) {
		Dataset copyDataset = new Dataset(dataset, 0);
		for (int k = 0; k < dataset.getExampleSize(); k++) {
			Example example = dataset.getExampleByIndex(k);
			copyDataset.addExample(example);
		}
		for (int k = 0; k < dataset.getCategorySize(); k++) {
			Category category = dataset.getCategory(k);
			copyDataset.addCategory(category);
		}
		for (int k = 0; k < dataset.getWorkerSize(); k++) {
			Worker worker = dataset.getWorkerByIndex(k);
			copyDataset.addWorker(worker);
		}
		return copyDataset;
	}
	
	// ����CHI�����㹤������
	public HashMap<String, Double> calQuality(Dataset dataset) {
		// ���չ����Ƿ��껮�����ݼ�
		subDataset = new HashMap<String, Dataset>();
		Dataset tempTrain = copyDataset(dataset);
		for(int eIndex=0; eIndex<tempTrain.getExampleSize(); eIndex++) {
			Example example = tempTrain.getExampleByIndex(eIndex);
			ArrayList<String> workerList = example.getWorkerIdList();
			for(int wIndex=0; wIndex<workerList.size(); wIndex++) {
				String w1 = workerList.get(wIndex);
				if(!subDataset.containsKey(w1)) {
					Dataset temp_dataset = new Dataset(tempTrain, 0);
					subDataset.put(w1, temp_dataset);
				}
				subDataset.get(w1).addExample(example);
			}
		}
		
		// ��ÿ�����˵����ݼ�����CHI
		HashMap<String, Double>workerQuality = new HashMap<String, Double>();
		for (String key : subDataset.keySet()) {
			workerQuality.put(key, calCHI(subDataset.get(key), key));
		}
		
		// ���������Ҳ���������С��һ��
		double min = Double.MAX_VALUE;
		double max = -1;
		for (String key : workerQuality.keySet()) {
			if (workerQuality.get(key) > max) {
				max = workerQuality.get(key);	
			}
			if (workerQuality.get(key) < min) {
				min = workerQuality.get(key);
			}
		}
		// �����С��һ��
		if(max != min) {
			for (String key : workerQuality.keySet()) {
				workerQuality.put(key, (workerQuality.get(key) - min) / (max - min));
			}
		}
		return workerQuality;
	}
	
	// ����CHI
	public double calCHI(Dataset dataset, String workerID) {
		if(dataset.numInstances() > 200) {
			int numClasses = dataset.numClasses();
			int numExamples = dataset.getExampleSize();
			int numAttributes = dataset.numAttributes();
			
			// �ȼ����������ݼ�������
			Instances total_Centroid = new Instances(dataset, 0);
			double[] vals = new double[numAttributes];
			for (int j = 0; j < numAttributes; j++) {
				vals[j] = dataset.meanOrMode(j);
			}
			total_Centroid.add(new Instance(1.0, vals)); 
			
			// �ٰ�����𻮷����ݼ�
			Dataset[] temp_Datasets = new Dataset[numClasses];
			for(int k=0; k<numClasses; k++) {
				temp_Datasets[k] = dataset.generateEmpty();
			}
			for(int i=0; i<numExamples; i++) {
				int label = dataset.getExampleByIndex(i).getNoisyLabelByWorkerId(workerID).getValue();//���ɱ�
				temp_Datasets[label].addExample(dataset.getExampleByIndex(i));
			}
			
			// Ȼ�����ÿ���������
			Instances m_Centroids = new Instances(dataset, numClasses);
			for(int k=0; k<numClasses; k++) {
				if(temp_Datasets[k].getExampleSize()==0) {
					m_Centroids.add(new Instance(numAttributes));//����һ������ȱʧ��ʵ��
				}
				else if(temp_Datasets[k].getExampleSize()==1) {
					m_Centroids.add(new Instance(temp_Datasets[k].instance(0)));//������Ψһ��ʵ��
				}
				else {
					vals = new double[numAttributes];
					for (int j = 0; j < numAttributes; j++) {
						vals[j] = temp_Datasets[k].meanOrMode(j);
					}
					m_Centroids.add(new Instance(1.0, vals));
				}
			}
			
			// ����CHI
			double temp1 = 0.0;
			double temp2 = 0.0;
			double temp3 = 0.0;
			for(int i=0; i<numClasses; i++) {
				if(temp_Datasets[i].getExampleSize() > 0) {
					temp3 += 1;
					// ���ۼӷ���
					temp1 += temp_Datasets[i].getExampleSize() * calHMOM(total_Centroid.instance(0), m_Centroids.instance(i));
					// ���ۼӷ�ĸ
					for(int j=0; j<temp_Datasets[i].getExampleSize(); j++) {
						Example ex = temp_Datasets[i].getExampleByIndex(j);
						temp2 += calHMOM(ex, m_Centroids.instance(i));
					}
				}
			}
			temp1 = temp1 / (temp3 - 1);
			temp2 = temp2 / (numExamples - temp3);
			if(temp2 != 0)
				return temp1 / temp2;
			else
				return 0.0;
		}
		else
			return 0.0;
	}

	public void doInference(Dataset data) throws Exception {
		m_numClasses = data.numClasses();
		m_numExamples = data.getExampleSize();
		m_numAttributes = data.numAttributes();
		m_instanceProb = new double[data.getExampleSize()][m_numClasses];
		
		m_MinArray = new double[m_numAttributes];
		m_MaxArray = new double[m_numAttributes];
		for (int m = 0; m < m_numAttributes; m++)
			m_MinArray[m] = Double.NaN;
		for(int i=0; i<m_numExamples; i++) {
			double[] value = data.instance(i).toDoubleArray();
			for(int m=0; m<m_numAttributes; m++) {
				if(data.attribute(m).isNumeric() && (data.classIndex() != m)) {
					if (!Instance.isMissingValue(value[m])) {
						if (Double.isNaN(m_MinArray[m])) {
							m_MinArray[m] = m_MaxArray[m] = value[m];
						} else {
							if (value[m] < m_MinArray[m])
								m_MinArray[m] = value[m];
							if (value[m] > m_MaxArray[m])
								m_MaxArray[m] = value[m];
						}
					}					
				}
			}
		}
		
		//Step 0: �ȼ��㹤�˵�Ȩ��
		HashMap<String, Double> Quality = calQuality(data);
		
		//Step 1�� �����������Ƿֲ�����
		calMNL(data, Quality);
		
		//Step 2�� �����Ӽ�
		divideSubsets(data, Quality);
		
		//Step 3���������ƶ����� calSimilarity ͬʱ�ں�
		calSimilarity(data);
		
		// this is important
		data.assignIntegeratedLabel2WekaInstanceClassValue();
	}
	
	public void calMNL(Dataset data, HashMap<String, Double> Quality) {
		double[] exLable = null;
		for (int j = 0; j < data.getExampleSize(); j++) {
			exLable = new double[m_numClasses];
			Example ex = data.getExampleByIndex(j);
			MultiNoisyLabelSet labelSet = ex.getMultipleNoisyLabelSet(0);
			for (int m = 0; m < labelSet.getLabelSetSize(); m++) {
				int labelclass = labelSet.getLabel(m).getValue();
				String workerid = labelSet.getLabel(m).getWorkerId();
				exLable[labelclass] += Quality.get(workerid);
			}
			if(Utils.sum(exLable) == 0) {
				for (int m = 0; m < labelSet.getLabelSetSize(); m++) {
					exLable[labelSet.getLabel(m).getValue()] += 1;
				}
			}
			Utils.normalize(exLable);			
			for(int k=0; k<m_numClasses; k++) {
				m_instanceProb[j][k] = exLable[k];
			}
		}
	}
	
	public void divideSubsets(Dataset dataset, HashMap<String, Double> Quality) {
		// ���ҵ����������ߵĹ���
		double max_value = -1;
		String max_key = "";
		for(String key : Quality.keySet()) {
			if(Quality.get(key) > max_value) {
				max_value = Quality.get(key);
				max_key = key;
			}
		}
		subDatasets = new Dataset[m_numClasses];
		for(int k=0; k<m_numClasses; k++) {
			subDatasets[k] = dataset.generateEmpty();
		}
		for(int i=0; i<subDataset.get(max_key).getExampleSize(); i++) {
			int label = subDataset.get(max_key).getExampleByIndex(i).getNoisyLabelByWorkerId(max_key).getValue();//���ɱ�
			subDatasets[label].addExample(subDataset.get(max_key).getExampleByIndex(i));
		}
	}
	
	public HashMap<Integer, Double> helpCal(Instance temp) {
		HashMap<Integer, Double> pro = new HashMap<Integer, Double>();
		for(int k=0; k<m_numClasses; k++) {
			if(subDatasets[k].numInstances() > 0) {
				double tempCount = 0.0;
				for(int i=0; i<subDatasets[k].numInstances(); i++) {
					tempCount += calHMOM(temp, subDatasets[k].instance(i));
				}
				pro.put(k, tempCount / subDatasets[k].numInstances());
			}
		}
		
		// ���������Ҳ���������С��һ��
		double min = Double.MAX_VALUE;
		double max = -1;
		for (Integer key : pro.keySet()) {
			if (pro.get(key)  > max)
				max = pro.get(key);
			if (pro.get(key) < min)
				min = pro.get(key);
		}
		// �����С��һ��
		if(max != min) {
			for (Integer key : pro.keySet()) {
				pro.put(key, (max - pro.get(key)) / (max - min));
			}
		}
		else {
			for (Integer key : pro.keySet()) {
				pro.put(key, 1.0 / pro.size());
			}
		}
		return pro;
	}
	
	public void calSimilarity(Dataset data) {
		
		m_probilities = new HashMap<String,double[]>();
		
		for(int i=0; i<m_numExamples; i++) {
			Example ex = data.getExampleByIndex(i);
			
			// �ȼ����һ���ֲ�
			double[] similarityProb = new double[m_numClasses];			
			HashMap<Integer, Double> pro = helpCal(ex);
			for(int k=0; k<m_numClasses; k++) {
				if(pro.containsKey(k))
					similarityProb[k] = pro.get(k);
				else
					similarityProb[k] = 0;
			}
			Utils.normalize(similarityProb);
			
			// ���ں������ֲ�
			for(int k=0; k<m_numClasses; k++) {
				similarityProb[k] += m_instanceProb[i][k];
			}
			int maxIndex = Utils.maxIndex(similarityProb);
			
			Utils.normalize(similarityProb);
			
			m_probilities.put(ex.getId(), similarityProb);
			
			//���輯�ɱ�
			Label label = new Label(null, String.valueOf(maxIndex), ex.getId(), "");
			ex.setIntegratedLabel(label);
		}
		
	}
	
	public HashMap<String, double[]> getPro(){
		return m_probilities;
	}
	
	public double calHMOM(Instance ins1, Instance ins2) {
		double distance = 0;
		for(int m=0; m<m_numAttributes; m++) {
			if(m == ins1.classIndex()) continue;
			if(ins1.isMissing(m) || ins2.isMissing(m))
				distance += 1;
			else if(ins1.attribute(m).isNominal()) {
				distance += (ins1.value(m) == ins2.value(m)) ? 0 :1;
			}
			else {
				if((m_MaxArray[m] - m_MinArray[m]) == 0)
					distance += 0;
				else
					distance += Math.abs(ins1.value(m) - ins2.value(m)) / (m_MaxArray[m] - m_MinArray[m]);
			}
			
		}		
		return distance;
	}
}
